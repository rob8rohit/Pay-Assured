# PayAssured — Invoice Recovery Case Tracker (Starter)
Contains a ready-to-run **backend (FastAPI)** and a simple **Node.js frontend (Express)** plus DB schema and examples.

## What is included
- backend/: FastAPI app (Python) with endpoints for clients and cases
- frontend/: Express app serving static HTML pages (Case List, Case Detail, Case Create)
- db/schema.sql: SQL to create tables
- .env.example: example environment variables
- screenshots/: placeholder images for submission

## How to run (backend)
1. Create a virtual env and install:
```bash
cd backend
python -m venv .venv
source .venv/bin/activate    # or .venv\Scripts\activate on Windows
pip install -r requirements.txt
```
2. Set DATABASE_URL in backend/.env or export it. Example in `.env.example`.
3. Start the app:
```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```
Open http://localhost:8000/docs for API docs.

## How to run (frontend)
1. Install node deps:
```bash
cd frontend
npm install
node server.js
```
2. Open http://localhost:3000
