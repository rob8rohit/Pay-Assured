from sqlalchemy import Column, Integer, String, ForeignKey, Numeric, Date, Text, DateTime
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from .db import Base

class Client(Base):
    __tablename__ = 'clients'
    id = Column(Integer, primary_key=True, index=True)
    client_name = Column(String(255), nullable=False)
    company_name = Column(String(255), nullable=False)
    city = Column(String(128))
    contact_person = Column(String(255))
    phone = Column(String(30))
    email = Column(String(255))
    cases = relationship('Case', back_populates='client')

class Case(Base):
    __tablename__ = 'cases'
    id = Column(Integer, primary_key=True, index=True)
    client_id = Column(Integer, ForeignKey('clients.id', ondelete='CASCADE'))
    invoice_number = Column(String(128), nullable=False)
    invoice_amount = Column(Numeric(12,2), nullable=False)
    invoice_date = Column(Date, nullable=False)
    due_date = Column(Date, nullable=False)
    status = Column(String(32), nullable=False, default='New')
    last_follow_up_notes = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    client = relationship('Client', back_populates='cases')
