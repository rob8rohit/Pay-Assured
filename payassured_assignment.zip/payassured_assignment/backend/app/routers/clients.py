from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from .. import crud, schemas
from ..db import get_db

router = APIRouter(prefix='/clients', tags=['clients'])

@router.post('', response_model=schemas.ClientOut, status_code=201)
def create_client(payload: schemas.ClientCreate, db: Session = Depends(get_db)):
    return crud.create_client(db, payload)

@router.get('', response_model=list[schemas.ClientOut])
def list_clients(db: Session = Depends(get_db)):
    return crud.list_clients(db)
