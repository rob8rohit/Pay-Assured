from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from .. import crud, schemas
from ..db import get_db

router = APIRouter(prefix='/cases', tags=['cases'])

@router.post('', response_model=schemas.CaseOut, status_code=201)
def create_case(payload: schemas.CaseCreate, db: Session = Depends(get_db)):
    new = crud.create_case(db, payload)
    if new is None:
        raise HTTPException(status_code=400, detail='Client not found')
    return new

@router.get('', response_model=list[schemas.CaseOut])
def list_cases(status: str | None = Query(None), sort: str = Query('asc'), db: Session = Depends(get_db)):
    sort_asc = sort != 'desc'
    return crud.list_cases(db, status=status, sort_asc=sort_asc)

@router.get('/{case_id}', response_model=schemas.CaseOut)
def get_case(case_id: int, db: Session = Depends(get_db)):
    case = crud.get_case(db, case_id)
    if not case:
        raise HTTPException(status_code=404, detail='Case not found')
    return case

@router.patch('/{case_id}', response_model=schemas.CaseOut)
def patch_case(case_id: int, payload: schemas.CaseUpdate, db: Session = Depends(get_db)):
    updates = {k: v for k, v in payload.dict().items() if v is not None}
    case = crud.patch_case(db, case_id, updates)
    if not case:
        raise HTTPException(status_code=404, detail='Case not found')
    return case
