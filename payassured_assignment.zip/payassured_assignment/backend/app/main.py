from fastapi import FastAPI
from .db import engine, Base
from .routers import clients, cases

# create tables (for dev). In production use alembic migrations.
Base.metadata.create_all(bind=engine)

app = FastAPI(title='PayAssured - Invoice Recovery Tracker')

app.include_router(clients.router)
app.include_router(cases.router)

@app.get('/')
def root():
    return {'status': 'ok'}
