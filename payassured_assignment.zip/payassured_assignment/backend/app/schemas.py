from pydantic import BaseModel, Field, EmailStr
from datetime import date
from typing import Optional

class ClientCreate(BaseModel):
    client_name: str = Field(...)
    company_name: str = Field(...)
    city: Optional[str]
    contact_person: Optional[str]
    phone: Optional[str]
    email: Optional[EmailStr]

class ClientOut(ClientCreate):
    id: int
    class Config:
        orm_mode = True

class CaseCreate(BaseModel):
    client_id: int
    invoice_number: str
    invoice_amount: float
    invoice_date: date
    due_date: date
    status: Optional[str] = 'New'
    last_follow_up_notes: Optional[str]

class CaseOut(CaseCreate):
    id: int
    class Config:
        orm_mode = True

class CaseUpdate(BaseModel):
    status: Optional[str]
    last_follow_up_notes: Optional[str]
