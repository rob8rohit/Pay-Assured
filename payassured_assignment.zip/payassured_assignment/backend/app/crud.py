from sqlalchemy.orm import Session
from . import models, schemas

def create_client(db: Session, client: schemas.ClientCreate):
    db_client = models.Client(**client.dict())
    db.add(db_client)
    db.commit()
    db.refresh(db_client)
    return db_client

def list_clients(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Client).offset(skip).limit(limit).all()

def create_case(db: Session, case: schemas.CaseCreate):
    client = db.query(models.Client).filter(models.Client.id == case.client_id).first()
    if not client:
        return None
    db_case = models.Case(**case.dict())
    db.add(db_case)
    db.commit()
    db.refresh(db_case)
    return db_case

def list_cases(db: Session, status: str = None, sort_asc: bool = True):
    q = db.query(models.Case)
    if status:
        q = q.filter(models.Case.status == status)
    q = q.order_by(models.Case.due_date.asc() if sort_asc else models.Case.due_date.desc())
    return q.all()

def get_case(db: Session, case_id: int):
    return db.query(models.Case).filter(models.Case.id == case_id).first()

def patch_case(db: Session, case_id: int, updates: dict):
    db_case = get_case(db, case_id)
    if not db_case:
        return None
    for k, v in updates.items():
        setattr(db_case, k, v)
    db.add(db_case)
    db.commit()
    db.refresh(db_case)
    return db_case
