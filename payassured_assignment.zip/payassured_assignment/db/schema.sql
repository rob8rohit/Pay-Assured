-- PostgreSQL schema
CREATE TABLE clients (
  id SERIAL PRIMARY KEY,
  client_name VARCHAR(255) NOT NULL,
  company_name VARCHAR(255) NOT NULL,
  city VARCHAR(128),
  contact_person VARCHAR(255),
  phone VARCHAR(30),
  email VARCHAR(255)
);

CREATE TABLE cases (
  id SERIAL PRIMARY KEY,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  invoice_number VARCHAR(128) NOT NULL,
  invoice_amount NUMERIC(12,2) NOT NULL,
  invoice_date DATE NOT NULL,
  due_date DATE NOT NULL,
  status VARCHAR(32) NOT NULL DEFAULT 'New',
  last_follow_up_notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);
